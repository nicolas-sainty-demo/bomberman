/*
** EPITECH PROJECT, 2021
** Indie_Studio
** File description:
** Generator.cpp
*/

#include "Generator.hpp"
#include <fstream>

Generator::Generator(int map_size, std::string file_path)
{
    this->map_size = map_size;
    this->file_path = file_path;

    srand(time(NULL));
    fill_map();
}

Generator::~Generator()
{
}

void Generator::fill_map()
{
    for (int i = 0; i < map_size; i = i + 1) {
        std::vector<char> v1;

        for (int j = 0; j < map_size; j = j + 1)
            v1.push_back(air);

        tab.push_back(v1);
    }
    add_border();
    add_ndw();
    add_dw();
    add_dw_bis();
    player_spawn();
    to_txt();
}

void Generator::add_border()
{
    for (int i = 0; i < map_size; i = i + 1)
        tmp.push_back(border);
    tab[0] = this->tmp;
    tab[map_size - 1] = this->tmp;

    for (int i = 0; i < (map_size - 1); i = i + 1) {
        tab[i][0] = border;
        tab[i][map_size - 1] = border;
    }
}

void Generator::add_ndw()
{
    int res = 3;
    int len = ((map_size - 4) / 2) + 1;
    int x1 = 2;
    int y1 = 2;
    int x2 = map_size - 3;
    int y2 = map_size - 3;
    int row;
    int col;


    for (nb_rep = 1; res < (map_size - 1) / 2; nb_rep = nb_rep + 1)
        res = res + 2;

    for (int  i = 0; i < nb_rep; i = i + 1) {
        row = x1;
        col = y1;
        for (int i = 0; i < len; i = i + 1) {
            tab[row][col] = ndw;
            col = col + 2;
        }
        x1 = x1 + 2;
        y1 = y1 + 2;
        len = len - 2;
    }

    len =  ((map_size - 4) / 2) + 1;
    for (int  i = 0; i < nb_rep; i = i + 1) {
        row = x2;
        col = y2;
        for (int i = 0; i < len; i = i + 1) {
            tab[row][col] = ndw;
            col = col - 2;
        }
        x2 = x2 - 2;
        y2 = y2 - 2;
        len = len - 2;
    }

    x1 = 2;
    y1 = 2;
    x2 = map_size - 3;
    y2 = map_size - 3;

    len = ((map_size - 4) / 2) + 1;
    for (int  i = 0; i < nb_rep; i = i + 1) {
        row = x2;
        col = y2;
        for (int i = 0; i < len; i = i + 1) {
            tab[row][col] = ndw;
            row = row - 2;
        }
        x2 = x2 - 2;
        y2 = y2 - 2;
        len = len - 2;
    }
    len = ((map_size - 4) / 2) + 1;
    for (int  i = 0; i < nb_rep; i = i + 1) {
        row = x1;
        col = y1;
        for (int i = 0; i < len; i = i + 1) {
            tab[row][col] = ndw;
            row = row + 2;
        }
        x1 = x1 + 2;
        y1 = y1 + 2;
        len = len - 2;
    }
}

void Generator::add_dw()
{
    int len = ((map_size - 4) / 2);
    int rep = nb_rep - 1;
    int x1 = 2;
    int y1 = 3;
    int x2 = map_size - 3;
    int y2 = map_size - 4;
    int row;
    int col;

    for (int  i = 0; i < nb_rep; i = i + 1) {
        row = x1;
        col = y1;
        for (int i = 0; i < len; i = i + 1) {
            tab[row][col] = selector();
            col = col + 2;
        }
        x1 = x1 + 2;
        y1 = y1 + 2;
        len = len - 2;
    }
    len = ((map_size - 4) / 2);
    for (int  i = 0; i < nb_rep; i = i + 1) {
        row = x2;
        col = y2;
        for (int i = 0; i < len; i = i + 1) {
            tab[row][col] = selector();
            col = col - 2;
        }
        x2 = x2 - 2;
        y2 = y2 - 2;
        len = len - 2;
    }

    x1 = 2;
    y1 = 3;
    x2 = map_size - 3;
    y2 = map_size - 4;
    len = ((map_size - 4) / 2);
    for (int  i = 0; i < nb_rep; i = i + 1) {
        row = x1;
        col = y1;
        for (int i = 0; i < len; i = i + 1) {
            tab[row][col] = selector();
            row = row + 2;
        }
        x1 = x1 + 2;
        y1 = y1 + 2;
        len = len - 2;
    }

    len = ((map_size - 4) / 2);
    for (int  i = 0; i < nb_rep; i = i + 1) {
        row = x2;
        col = y2;
        for (int i = 0; i < len; i = i + 1) {
            tab[row][col] = selector();
            row = row - 2;
        }
        x2 = x2 - 2;
        y2 = y2 - 2;
        len = len - 2;
    }
}

void Generator::add_dw_bis()
{
    int len = map_size - 2;
    int rep = nb_rep - 1;
    int x1 = 1;
    int y1 = 1;
    int x2 = map_size - 2;
    int y2 = map_size - 2;
    int row;
    int col;

    for (int  i = 0; i < nb_rep; i = i + 1) {
        row = x1;
        col = y1;
        for (int i = 0; i < len; i = i + 1) {
            tab[row][col] = selector();
            col++;
        }
        x1 = x1 + 2;
        y1 = y1 + 2;
        len = len - 4;
    }
    len = map_size - 2;
    for (int  i = 0; i < nb_rep; i = i + 1) {
        row = x2;
        col = y2;
        for (int i = 0; i < len; i = i + 1) {
            tab[row][col] = selector();
            col--;
        }
        x2 = x2 - 2;
        y2 = y2 - 2;
        len = len - 4;
    }

    x1 = 1;
    y1 = 1;
    x2 = map_size - 2;
    y2 = map_size - 2;
    len = map_size - 2;
    for (int  i = 0; i < nb_rep; i = i + 1) {
        row = x1;
        col = y1;
        for (int i = 0; i < len; i = i + 1) {
            tab[row][col] = selector();
            row++;
        }
        x1 = x1 + 2;
        y1 = y1 + 2;
        len = len - 4;
    }
    len = map_size - 2;
    for (int  i = 0; i < nb_rep; i = i + 1) {
        row = x2;
        col = y2;
        for (int i = 0; i < len; i = i + 1) {
            tab[row][col] = selector();
            row--;
        }
        x2 = x2 - 2;
        y2 = y2 - 2;
        len = len - 4;
    }
}

void Generator::player_spawn()
{
    tab[1][1] = air;
    tab[1][2] = air;
    tab[2][1] = air;

    tab[1][map_size - 2] = air;
    tab[1][map_size - 3] = air;
    tab[2][map_size - 2] = air;

    tab[map_size - 2][1] = air;
    tab[map_size - 3][1] = air;
    tab[map_size - 2][2] = air;

    tab[map_size - 2][map_size - 2] = air;
    tab[map_size - 3][map_size - 2] = air;
    tab[map_size - 2][map_size - 3] = air;
}

char Generator::selector()
{
    char c;
    int i;

    i = (rand() % 2);

    if (i == 0)
        c = air;
    if (i == 1)
        c = dw;

    return (c);
}

void Generator::to_txt()
{
    std::ofstream fw("./map.txt", std::ofstream::out);

    if (fw.is_open()) {
        for (int j = 0; j < map_size; j = j + 1) {
            for (int i = 0; i < map_size; i = i + 1)
                fw << tab[j][i];
            fw << "\n";
        }
    }
}
