/*
** EPITECH PROJECT, 2021
** Indie_Studio
** File description:
** Map_Generator.hpp
*/

#include <string>
#include <vector>
#include <stdlib.h>
#include <time.h>
#include <iostream>

#ifndef GENERATOR_HPP_
    #define GENERATOR_HPP_

/* border => border of the map, dw => destructible wall, ndw => non destructible wall */
enum obstacles {border = 'I', dw = 'X', ndw = '0', air = ' '};

class Generator
{
    private:
        int map_size;
        int nb_rep;
        std::string file_path;
        std::vector<std::vector<char>> tab;
        std::vector<char> tmp;

    public:
        void fill_map();
        void add_border();
        void add_ndw();
        void add_dw();
        void add_dw_bis();
        void player_spawn();
        void fill_space();
        char selector();
        void to_txt();
        Generator(int map_size, std::string file_path);
        ~Generator();
};

#endif /* GENERATOR_HPP_ */
